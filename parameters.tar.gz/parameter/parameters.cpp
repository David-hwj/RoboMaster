
#include <parameters.h>

/*
根据文件读取参数
*/
void readParameters(const char* filePath,map<string,vector<Pixel> > &parameters){
	ifstream read(filePath);
	if(!read){
		cout<<"ifstream打开文件失败"<<endl;
	}
	else{
		parameters.clear();
		char c='?';
		int a=-1;
		vector<Pixel> pVec;
		Pixel p={-1,-1,-1};
		while(true){//cout<<c<<" "<<a<<endl;
			read>>c;
			if(c=='h'||c=='b'){
				c='?';read>>a;p.h_b=a;
			}
			else if(c=='s'||c=='g'){
				c='?';read>>a;p.s_g=a;
			}
			else if(c=='v'){
				c='?';read>>a;p.v_r=a;
				pVec=parameters["HSV"];
				pVec.push_back(p);
				parameters["HSV"]=pVec;
			}
			else if(c=='r'){
				c='?';read>>a;p.v_r=a;
				pVec=parameters["BGR"];
				pVec.push_back(p);
				parameters["BGR"]=pVec;
			}
			else if(c=='.'){
				break;
			}
			else{
				 cout<<"配置文件格式不规范"<<endl;break;
			}
		}

		read.close();
	}
}
/*传入配置文件路径和一个包含数据的map，将参数写入文件
**
*/
void writeParameters(const char* filePath,map<string,vector<Pixel> > &parameters){
	ofstream write(filePath);
	if(!write){
		cout<<"ofstream打开文件失败"<<endl;
	}
	else{
		vector<Pixel> pVec=parameters["HSV"];
		for(int i=0;i<pVec.size();i++){
			write<<"h "<<pVec[i].h_b<<" s "<<pVec[i].s_g<<" v "<<pVec[i].v_r<<endl;
		}
		pVec=parameters["BGR"];
		for(int i=0;i<pVec.size();i++){
			write<<"b "<<pVec[i].h_b<<" g "<<pVec[i].s_g<<" r "<<pVec[i].v_r<<endl;
		}
		write<<".";
		write.close();
	}
}
/*
控制台输出参数
*/
void display(map<string,vector<Pixel> > &parameters){
	vector<Pixel> pVec=parameters["HSV"];
	for(int i=0;i<pVec.size();i++){
		cout<<"h:"<<pVec[i].h_b<<" s:"<<pVec[i].s_g<<" v:"<<pVec[i].v_r<<endl;
	}
	pVec=parameters["BGR"];
	for(int i=0;i<pVec.size();i++){
		cout<<"b:"<<pVec[i].h_b<<" g:"<<pVec[i].s_g<<" r:"<<pVec[i].v_r<<endl;
	}
}
/*
把像素值加入map
*/
void addPixel(map<string,vector<Pixel> > &parameters,string HSV_BGR,Pixel p){
	vector<Pixel> pVec=parameters[HSV_BGR];
	pVec.push_back(p);
}
void addPixel(map<string,vector<Pixel> > &parameters,string HSV_BGR,int h_b,int s_g,int v_r){
	vector<Pixel> pVec=parameters[HSV_BGR];
	Pixel p={h_b,s_g,v_r};
	pVec.push_back(p);
}
