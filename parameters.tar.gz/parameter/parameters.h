#ifndef PARAMETERS_H
#define PARAMETERS_H

#include <iostream>
#include <fstream>
#include <map>
#include <vector>
using namespace std;


typedef struct HSV_BGR{
	int h_b;
	int s_g;
	int v_r;

}Pixel;
void readParameters(const char* filePath,map<string,vector<Pixel> > &parameters);
void writeParameters(const char* filePath,map<string,vector<Pixel> > &parameters);
void display(map<string,vector<Pixel> > &parameters);
void addPixel(map<string,vector<Pixel> > &parameters,string HSV_BGR,Pixel p);
void addPixel(map<string,vector<Pixel> > &parameters,string HSV_BGR,int h_b,int s_g,int v_r);

#endif
