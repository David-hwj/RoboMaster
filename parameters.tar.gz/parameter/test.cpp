#include <iostream>
#include <parameters.h>

using namespace std;

const char* filePath="./HSV_BGR.para";
const char* filePath2="./ParaTest.para";

int main(){

	cout<<endl<<endl<<"参数文件测试程序"<<endl<<endl<<endl;

	map<string,vector<Pixel> > parameters;
	cout<<"开始读取参数文件，文件路径："<<filePath<<endl;
	readParameters(filePath2,parameters);
	cout<<"参数读取完毕,数据如下："<<endl;
	display(parameters);
	
	cout<<"开始下写入文件"<<endl;
	writeParameters(filePath,parameters);
	cout<<"参数写入完毕，文件路径："<<filePath2<<endl;



	return 0;
}



